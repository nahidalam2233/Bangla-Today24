package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = NewsRedLight,
    onPrimary = Color.Black,
    primaryContainer = NewsRedDark,
    onPrimaryContainer = NewsRedContainer,
    secondary = Color(0xFF4DB6AC),
    onSecondary = Color.Black,
    secondaryContainer = NewsGreenSecondary,
    onSecondaryContainer = NewsGreenContainer,
    tertiary = Color(0xFFFFB74D),
    background = BackgroundDark,
    surface = SurfaceDark,
    onBackground = TextPrimaryDark,
    onSurface = TextPrimaryDark,
    surfaceVariant = Color(0xFF2C2C35),
    onSurfaceVariant = TextSecondaryDark,
  )

private val LightColorScheme =
  lightColorScheme(
    primary = NewsRedPrimary,
    onPrimary = Color.White,
    primaryContainer = NewsRedContainer,
    onPrimaryContainer = NewsOnRedContainer,
    secondary = NewsGreenSecondary,
    onSecondary = Color.White,
    secondaryContainer = NewsGreenContainer,
    onSecondaryContainer = NewsOnGreenContainer,
    tertiary = NewsAmberAccent,
    background = BackgroundLight,
    surface = SurfaceLight,
    onBackground = TextPrimaryLight,
    onSurface = TextPrimaryLight,
    surfaceVariant = Color(0xFFECEFF1),
    onSurfaceVariant = TextSecondaryLight,
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false, // Preserve branded red/green theme for news authenticity
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }
      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
